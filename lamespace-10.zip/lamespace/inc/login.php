<h2>Login To LameSpace</h2>
<!--load the login widget-->
<?php 

	// Load the registration form. Since this file was 
	// loaded from index.php (which is outside) widgets 
	// we can just put 'widgets/' instead of '../widgets'
	require( 'widgets/login.php' );

?>