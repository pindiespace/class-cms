<!--home page for logged-in members-->
<h2>Welcome, Member!</h2>

<div class="member-info">
	<p>Your name:</p>

</div>

