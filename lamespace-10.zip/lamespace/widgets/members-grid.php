					<div class="members-grid">

						<div class="row">
							<div class="column">
								<img src="img/profile-picture.png" width="200" height="200">
							</div>
							<div class="column">
								<img src="img/profile-picture.png" width="200" height="200">
							</div>
						</div><!--end of left-hand column-->

						<div class="row">
							<div class="column">
								<img src="img/profile-picture.png" width="200" height="200">
							</div>
							<div class="column">
								<img src="img/profile-picture.png" width="200" height="200">
							</div>
						</div><!--end of right-hand column-->

					</div><!--end of members grid-->

