					<form id="ls_login_form" method="post" action="index.php">

						<h3>Login to Lamespace:</h3>

						<label>Username: 
							<input type="text" name="ls_username">
							<span class="form-error"></span>
						</label>

						<label>Password: 
							<input type="text" name="ls_password">
							<span class="form-error"></span>
						</label>

						<input type="submit" name="ls_login_form" class="login" value="Login">

					</form>