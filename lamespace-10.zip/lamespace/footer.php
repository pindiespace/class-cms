		<footer>

			<h2>Explore Lamespace</h2>

			<div class="row">

				<div class="column">
					<img width="100" height="100">
				</div>

				<nav class="column sitemap">

					<?php require( 'widgets/sitemap.php' ); ?>

				</nav>

				<div class="column legal">
					
					<p> &copy; 2017 Vegan Meat Market. All rights reserved.</p>

				</div>

			</div>


		</footer>

		<!--load bootstrap Ui functions-->

		<script src="js/jquery-3.1.1.min.js"></script>

		<script src="js/bootstrap.js"></script>

		<!--load our local app JS -->

		<script src="js/lamespace.js"></script>

	</body>

</html>


