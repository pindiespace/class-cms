<?php 
class LameSpace {

	// Our Controller class, imports Model and View

	// Constructor function
	function __construct ( $model=null, $view=null ) {

		// Save local reference to Model and View

		$this->model = $model;

		$this->view = $view;

		echo 'I\'m in LameSpace construct function<br>';

	}

	/** 
	 * route form data sent with $_POST
	 */
	function route_posts () {

		if ( isset( $_POST ) ) { // only process if $_POST exists

			if ( count( $_POST ) < 1 ) { // only process if $_POST has > 0 values

				echo 'NO $_POST VALUES<br>';

			} else {

				echo 'HAVE $_POST VALUES<br>';

				/////////////////
				if ( isset( $_POST[ 'ls_registration_form'] ) ) {

					$ls_user_first_name = htmlspecialchars( $_POST[ 'ls_user_first_name' ] );

					$ls_user_last_name = htmlspecialchars( $_POST[ 'ls_user_last_name' ] );

					$ls_user_email = htmlspecialchars( $_POST[ 'ls_user_email' ] );
					
					$ls_username = htmlspecialchars( $_POST[ 'ls_username' ] );

					$ls_password = htmlspecialchars( $_POST[ 'ls_password' ] );

					echo 'REGISTRATION FORM WAS SUBMITTED!!!!<br>';

					$this->model->process_registration( 
						$ls_user_first_name, 
						$ls_user_last_name,
						$ls_user_email,
						$ls_username,
						$ls_password
					);

					// ask the Model to process the registration form data

				} else if ( isset( $_POST['ls_login_form' ] ) ) {

					echo 'LOGIN FORM WAS SUBMITTED!!!!!<br>';

					// TODO: make a login form, and add code here to handle it.

					// ask the Model to process the login form data

				} else if ( isset( $_POST[ 'ls_picture_upload_form' ] ) ) {

					// ask the Model to process the picture upload form

				} else {

					// Error, we should NEVER go here.

					echo 'ERROR: INVALID FORM SUBMIT!!!!';

				}

				////////////////

				foreach ( $_POST as $key => $val ) { // loop through all $_POST variables

					echo "post key:".$key." value:".$val."<br>"; 

				} // end of foreach() loop

			} // end of else (have $_POST values)

		} // end of isset( $_POST )

	} // end of route_posts()

	/** 
	 * route to different pages, based on value of $_GET
	 */
	function route_page () {

		// Check to see if the user selected a menu item.

		if ( isset( $_GET[ 'pg' ] ) ) {

			$ls_which_menu = htmlspecialchars( $_GET[ 'pg' ] );

		} else {

			$ls_which_menu = 'home';

		}

		echo "MENU ITEM:" . $ls_which_menu . "<br>";

		echo "TRYING TO CALL VIEW<br>";

		// Have the View draw the correct page for this menu

		$this->view->load_page_by_menu( $ls_which_menu );

		echo "JUST TRIED CALLING VIEW";


	} // end of route_page

} // end of class LameSpace