<?php 

	require_once( 'lib/model.php' );
	require_once( 'lib/view.php' );
	require_once( 'lib/lamespace.php' );

?>
<?php require_once( 'header.php' ); ?>

		<main>

		<section id="content">

		<?php 
			
			$model = new LS_Model();

			$view = new LS_View();

			$lamespace = new LameSpace( $model, $view ); // create a PHP object

			$lamespace->route_posts(); // if a form was clicked ($_POST), route it

			$lamespace->route_page(); // otherwise, route $_GET

		?>

		</section>

		</main>

<?php require_once( 'footer.php' ); ?>
