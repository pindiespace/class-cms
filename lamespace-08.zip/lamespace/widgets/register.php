					<form method="post" action="index.php">

					 	<h3>Register for Lamespace</h3>
						<label>Name: <input type="text" name="ls_user_first_name"></label>
						<label>Last Name: <input type="text" name="ls_user_last_name"></label>
						<label>Email: <input type="text" name="ls_user_email"></label>
						<label>Username: <input type="text" name="ls_username"></label>
						<label>Password: <input type="password" name="ls_password"></label>
						<input type="submit" name="ls_registration_form" class="register" value="Register">

					</form>