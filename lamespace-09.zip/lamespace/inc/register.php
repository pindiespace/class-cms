<h2>Register for LameSpace</h2>
<!--load the registration widget-->
<?php 

	// Load the registration form. Since this file was 
	// loaded from index.php (which is outside) widgets 
	// we can just put 'widgets/' instead of '../widgets'
	require( 'widgets/register.php' );

?>