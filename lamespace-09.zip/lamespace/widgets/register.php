					<form id="ls_reg_form" method="post" action="index.php">

					 	<h3>Register for Lamespace</h3>

						<label>Name: 
							<input type="text" name="ls_user_first_name">
							<span class="form-error"></span>
						</label>

						<label>Last Name: 
							<input type="text" name="ls_user_last_name">
							<span class="form-error"></span>
						</label>

						<label>Email: 
							<input type="text" name="ls_user_email">
							<span class="form-error"></span>
						</label>

						<label>Username: 
							<input type="text" name="ls_username">
							<span class="form-error"></span>
						</label>


						<label>Password: 
							<input type="password" name="ls_password">
							<span class="form-error"></span>;
						</label>


						<input type="submit" name="ls_registration_form" class="register" value="Register">

					</form>