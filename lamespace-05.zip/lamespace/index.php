<?php require_once( 'header.php' ); ?>

		<main>

		<section id="content">

			<h2 class="hide-ui">Main Site Content</h2>

			<article id="cta" class="row">

				<h2>Join Our Lamespace</h2>

				<section class="cta-row cta-image">
					<img src="img/cta.png" width="500" height="500">
				</section>

				<section class="cta-row cta-text">
					<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
				</section>

			</article>

			<article id="see-stuff" class="row">
				
				<h2>See Our Stuff!</h2>

				<section class="members-row">

					<h3>Members</h3>

					<?php require( 'widgets/members-grid.php' ); ?>

				</section>


				<section class="members-row">

					<h3>Sign Up for Lamespace!</h3>

					<?php require( 'widgets/register.php' ); ?>

				</section>


			</article>

		</section>

		</main>

<?php require_once( 'footer.php' ); ?>
