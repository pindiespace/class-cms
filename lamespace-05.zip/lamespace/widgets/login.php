					<form>

						<label>Username: <input type="text"></label>
						<label>Password: <input type="text"></label>
						<button class="register">Login</button>

					</form>