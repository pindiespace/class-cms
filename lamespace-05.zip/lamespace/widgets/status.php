						<div class="status">
							<p class="status-msg">Not Logged In.</p>
							<p class="status-img"><img width="20" height="20">
						</div>