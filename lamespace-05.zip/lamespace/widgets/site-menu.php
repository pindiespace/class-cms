				<ul>
					<li>Home</li>
					<li>About</li>
					<li>Posts</li>
					<li>Members</li>
					<li>Register</li>
					<li>Contact</li>
				</ul>