					<ul>
						<li>Home</li>
						<li>About</li>
						<li>Register</li>
						<li>Login</li>
						<li>Members</li>
						<li>Contact</li>
					</ul>