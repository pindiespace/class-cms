<?php 
class LS_Model {

	// Database methods go here.

	function __construct () {

		echo 'I am in Model';

	}


	/** 
	 * Process registration, making sure people can't register twice.
	 */
	function process_registration ( $ls_user_name, $ls_user_email, $ls_username, $ls_password ) {

		echo '<span style="color:green">I am in the Model->process_registration() method</span><br>';

	}

	/**
	 * Process logins, with error messages for login fail.
	 */
	function process_login ( $ls_user_name, $ls_user_password ) {

		echo '<span style="color:green">I am in the Model->process_login() method</span><br>';

	}

	/** 
	 * Process the user trying to upload an Avatar picture.
	 */
	function process_picture_upload () {

		echo '<span style="color:green">I am in Model->process_picture_upload() method</span><br>';

	}


}