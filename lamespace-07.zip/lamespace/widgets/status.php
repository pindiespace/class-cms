						<div class="status">

							<!-- conditionally show a tiny login icon, or 
							a link that lets users log in. -->

							<!--link to log in-->
							<p class="status-msg">Not Logged In.
								<a href="index.php?pg=login">Log In</a>
							</p>

							<!--image that shows you're logged in (tiny icon) -->
							<p class="status-img"><img width="20" height="20">

						</div>