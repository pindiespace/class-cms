				<ul>
					<li><a href="index.php?pg=home">Home</a></li>
					<li><a href="index.php?pg=about">About</a></li>
					<li><a href="index.php?pg=posts">Posts</a></li>
					<li><a href="index.php?pg=members">Members</a></li>
					<li><a href="index.php?pg=register">Register</a></li>
					<li><a href="index.php?pg=contact">Contact</a></li>
				</ul>