					<form>
					 	<h3>Register for Lamespace</h3>
						<label>Name: <input type="text"></label>
						<label>Email: <input type="text"></label>
						<button class="register">Register</button>

					</form>