<?php require_once( 'lib/lamespace.php' ); ?>
<?php require_once( 'header.php' ); ?>

		<main>

		<section id="content">

		<?php 
			
			$lamespace = new LameSpace(); // create a PHP object

			$lamespace->route_page(); // exectue an object method

		?>

		</section>

		</main>

<?php require_once( 'footer.php' ); ?>
