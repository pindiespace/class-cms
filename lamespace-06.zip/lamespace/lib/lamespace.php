<?php 
class LameSpace {

	// Our Controller class, imports Model and View

	// Constructor function
	function __construct ( $model=null, $view=null ) {
		echo 'I\'m in construct function<br>';
		}

	function route_page () {

		// Check to see if the user selected a menu item.

		if ( isset( $_GET[ 'pg' ] ) ) {

			$which_menu = $_GET[ 'pg' ];

		} else {

			$which_menu = 'home';

		}

		echo "MENU ITEM:".$which_menu;

		// Routing table

		switch( $which_menu ) {

			case 'home':
				require( 'inc/home.php' );
				break;
			case 'about':
				require( 'inc/about.php' );
				break;
			case 'members':
				require( 'inc/members.php' );
				break;
			case 'posts':
				require( 'inc/posts.php' );
				break;
			case 'register':
				require( 'inc/register.php' );
				break;
			case 'contact':
				require( 'inc/contact.php' );
				break;
			default:
				require( 'inc/home/php' );
				break;

		} // end of switch


	} // end of route_page

} // end of class LameSpace