<?php 
class LS_Model {
	// Database methods go here.
	function __construct () {

		echo 'I am in Model';

	}

}