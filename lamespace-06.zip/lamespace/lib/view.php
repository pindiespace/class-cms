<?php
class LS_View {

	function __construct () {

		echo 'I am in View ';

	}

}