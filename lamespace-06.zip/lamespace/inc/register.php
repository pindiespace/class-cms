<?php 
?><h2>Register for LameSpace</h2><?php 
	require( 'widgets/register.php' );
